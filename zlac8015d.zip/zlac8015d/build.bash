#!/bin/bash

g++ -O3 main.cpp -I/usr/local/include/modbus -lmodbus #-L/usr/local/lib/limodbus.so
