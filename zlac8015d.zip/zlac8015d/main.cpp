#include <iostream>
#include <modbus.h>
#include <errno.h>
#include <unistd.h>
#include <time.h>
#include <signal.h>

static volatile int keepRunning = 1;
void signal_handler(int signum) {
  std::cerr<<std::endl<<"catch signum = "<<signum<<std::endl;
  keepRunning = 0;
}

int main()
{
  struct timespec ts;
  modbus_t *mb_ctx;
  
  mb_ctx = modbus_new_rtu("/dev/ttyUSB0", 115200, 'N', 8, 1);
  if( mb_ctx == NULL )
  {
     std::cout<<"connection error: mb_ctx == NULL"<<std::endl;
     return -1;
  }
  
  uint32_t sec = 5;
  uint32_t usec = 0;
  modbus_set_response_timeout(mb_ctx, sec, usec);
  if( modbus_connect(mb_ctx) == -1 )
  {
     std::cout<<"connection error: "<<modbus_strerror(errno)<<std::endl;
     modbus_free(mb_ctx);
     return -1;
  }

  int slave = 1;
  if( modbus_set_slave(mb_ctx, slave) == -1 )
  {
     std::cout<<"connection error: "<<modbus_strerror(errno)<<std::endl;
  }
  std::cout<<"[modbus connection done]"<<std::endl;

  int ret = modbus_write_register(mb_ctx, 8205, 4); // 200Dh control mode, 4: torque mode
  if( ret == -1 )
  {
     std::cout<<"write error: "<<modbus_strerror(errno)<<std::endl;
  }

  modbus_write_register(mb_ctx, 8206, 8);// 200Eh Control word, 0x08: enable
  std::cout<<"[motor enabled]"<<std::endl;




  sleep(1);
  uint16_t readrawdata[8];
  clock_gettime(CLOCK_MONOTONIC, &ts);
  double time1 = ts.tv_sec + 0.000000001*ts.tv_nsec;
  // read sample
  modbus_read_registers(mb_ctx, 8359, 8, readrawdata); // 20A7h, 20A8h, 20A9h, 20AAh, 20ABh, 20ACh, 20ADh, 20AEh Actual motor position high 16 bits(Left), position low 16 bits(Left), position high 16 bits(Right), position low 16 bits(Right), 
  // write sample
  modbus_write_register(mb_ctx, 8336, 400); // 2090h Target torque(Left) Unit: mA
  modbus_write_register(mb_ctx, 8337, 350); // 2091h Target torque(Right) Unit: mA
  clock_gettime(CLOCK_MONOTONIC, &ts);
  double time2 = ts.tv_sec + 0.000000001*ts.tv_nsec;
  std::cout<<"diff: "<<time2-time1<<std::endl;
  std::cout<<"readrawdata: "<<readrawdata[0]<<", "<<readrawdata[1]<<", "<<readrawdata[2]<<", "<<readrawdata[3]<<", "<<readrawdata[4]<<", "<<readrawdata[5]<<", "<<readrawdata[6]<<", "<<readrawdata[7]<<", "<<std::endl;  
  sleep(3);  




  modbus_write_register(mb_ctx, 8336, 0);
  modbus_write_register(mb_ctx, 8337, 0);
  modbus_write_register(mb_ctx, 8206, 8);// 200Eh Control word, 0x07: stop
  std::cout<<"[motor unabled]"<<std::endl;
  sleep(3);  
  modbus_close(mb_ctx);  
  std::cout<<"[modobus disconnection done]"<<std::endl;
  return 0;
}
